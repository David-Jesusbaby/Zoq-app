'use client';

import React from 'react';
import { cn } from '@/utils/cn';

interface AvatarProps {
  src?: string;
  alt?: string;
  name?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  isStory?: boolean;
  hasStory?: boolean;
}

const Avatar = ({
  src,
  alt = '',
  name = '',
  size = 'md',
  className,
  isStory = false,
  hasStory = false,
}: AvatarProps) => {
  const sizes = {
    xs: 'w-6 h-6 text-xs',
    sm: 'w-8 h-8 text-sm',
    md: 'w-10 h-10 text-base',
    lg: 'w-14 h-14 text-lg',
    xl: 'w-20 h-20 text-xl',
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  if (isStory || hasStory) {
    return (
      <div
        className={cn(
          'relative rounded-full p-[2px]',
          hasStory && 'bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500',
          className
        )}
      >
        <div className={cn('rounded-full bg-black p-[2px]', sizes[size])}>
          {src ? (
            <img
              src={src}
              alt={alt}
              className="w-full h-full rounded-full object-cover"
            />
          ) : (
            <div className="w-full h-full rounded-full bg-gradient-to-br from-[#00d4ff] to-purple-600 flex items-center justify-center text-white font-medium">
              {getInitials(name)}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={cn('rounded-full overflow-hidden', sizes[size], className)}>
      {src ? (
        <img
          src={src}
          alt={alt}
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="w-full h-full bg-gradient-to-br from-[#00d4ff] to-purple-600 flex items-center justify-center text-white font-medium">
          {getInitials(name)}
        </div>
      )}
    </div>
  );
};

export default Avatar;
