'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Plus, X } from 'lucide-react';
import Avatar from '@/components/ui/Avatar';
import { useAuth } from '@/context/AuthContext';
import { Story } from '@/types';
import { cn } from '@/utils/cn';

const Stories = () => {
  const { user, isAuthenticated } = useAuth();
  const [stories, setStories] = useState<Story[]>([]);
  const [selectedStory, setSelectedStory] = useState<Story | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newStoryImage, setNewStoryImage] = useState('');
  const [newStoryCaption, setNewStoryCaption] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchStories();
  }, []);

  const fetchStories = async () => {
    try {
      const response = await fetch('/api/stories');
      if (response.ok) {
        const data = await response.json();
        setStories(data.stories);
      }
    } catch (error) {
      console.error('Failed to fetch stories:', error);
    }
  };

  const handleCreateStory = async () => {
    if (!newStoryImage) return;

    try {
      const token = localStorage.getItem('zoq_token');
      const response = await fetch('/api/stories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          image: newStoryImage,
          caption: newStoryCaption,
        }),
      });

      if (response.ok) {
        setIsCreating(false);
        setNewStoryImage('');
        setNewStoryCaption('');
        fetchStories();
      }
    } catch (error) {
      console.error('Failed to create story:', error);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewStoryImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Group stories by user
  const storiesByUser = stories.reduce((acc, story) => {
    const userId = story.author.id;
    if (!acc[userId]) {
      acc[userId] = {
        author: story.author,
        stories: [],
      };
    }
    acc[userId].stories.push(story);
    return acc;
  }, {} as Record<string, { author: Story['author']; stories: Story[] }>);

  return (
    <>
      {/* Stories Bar */}
      <div className="flex gap-4 overflow-x-auto hide-scrollbar py-4 px-4 border-b border-neutral-800">
        {/* Add Story Button */}
        {isAuthenticated && (
          <button
            onClick={() => setIsCreating(true)}
            className="flex flex-col items-center gap-1 flex-shrink-0"
          >
            <div className="relative w-16 h-16 rounded-full border-2 border-dashed border-neutral-600 flex items-center justify-center hover:border-[#00d4ff] transition-colors">
              <Plus size={24} className="text-neutral-400" />
            </div>
            <span className="text-xs text-neutral-400">Add Story</span>
          </button>
        )}

        {/* User Stories */}
        {Object.values(storiesByUser).map(({ author, stories }) => (
          <button
            key={author.id}
            onClick={() => setSelectedStory(stories[0])}
            className="flex flex-col items-center gap-1 flex-shrink-0"
          >
            <Avatar
              src={author.avatar}
              name={author.name}
              size="lg"
              hasStory={true}
            />
            <span className="text-xs text-neutral-400 truncate max-w-[64px]">
              {author.username}
            </span>
          </button>
        ))}
      </div>

      {/* Create Story Modal */}
      {isCreating && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
          <div className="bg-neutral-900 rounded-2xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-neutral-800">
              <h3 className="text-lg font-semibold">Create Story</h3>
              <button
                onClick={() => setIsCreating(false)}
                className="p-2 hover:bg-neutral-800 rounded-lg transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-4 space-y-4">
              {!newStoryImage ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-neutral-700 rounded-xl h-64 flex flex-col items-center justify-center cursor-pointer hover:border-[#00d4ff] transition-colors"
                >
                  <Plus size={48} className="text-neutral-500 mb-2" />
                  <p className="text-neutral-400">Click to upload image</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="relative">
                  <img
                    src={newStoryImage}
                    alt="Story preview"
                    className="w-full h-64 object-cover rounded-xl"
                  />
                  <button
                    onClick={() => setNewStoryImage('')}
                    className="absolute top-2 right-2 p-2 bg-black/50 rounded-full hover:bg-black/70 transition-colors"
                  >
                    <X size={16} />
                  </button>
                </div>
              )}

              <textarea
                value={newStoryCaption}
                onChange={(e) => setNewStoryCaption(e.target.value)}
                placeholder="Add a caption..."
                className="w-full px-4 py-3 rounded-xl bg-neutral-800 border border-neutral-700 text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#00d4ff] resize-none"
                rows={2}
                maxLength={200}
              />

              <button
                onClick={handleCreateStory}
                disabled={!newStoryImage}
                className="w-full py-3 bg-[#00d4ff] text-black font-semibold rounded-xl hover:bg-[#00d4ff]/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Share Story
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Story Viewer */}
      {selectedStory && (
        <StoryViewer
          story={selectedStory}
          onClose={() => setSelectedStory(null)}
        />
      )}
    </>
  );
};

interface StoryViewerProps {
  story: Story;
  onClose: () => void;
}

const StoryViewer = ({ story, onClose }: StoryViewerProps) => {
  const [progress, setProgress] = useState(0);
  const progressRef = useRef<number>(0);

  useEffect(() => {
    const duration = 5000; // 5 seconds
    const interval = 50;
    const step = 100 / (duration / interval);

    const timer = setInterval(() => {
      progressRef.current += step;
      setProgress(progressRef.current);

      if (progressRef.current >= 100) {
        clearInterval(timer);
        onClose();
      }
    }, interval);

    return () => clearInterval(timer);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      {/* Progress Bar */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-neutral-800">
        <div
          className="h-full bg-white transition-all duration-50"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <Avatar
            src={story.author.avatar}
            name={story.author.name}
            size="sm"
          />
          <div>
            <p className="font-medium text-white">{story.author.name}</p>
            <p className="text-xs text-neutral-400">
              {new Date(story.createdAt).toLocaleTimeString()}
            </p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 hover:bg-white/10 rounded-full transition-colors"
        >
          <X size={24} className="text-white" />
        </button>
      </div>

      {/* Story Image */}
      <div className="flex-1 flex items-center justify-center">
        <img
          src={story.image}
          alt="Story"
          className="max-w-full max-h-full object-contain"
        />
      </div>

      {/* Caption */}
      {story.caption && (
        <div className="p-4 bg-gradient-to-t from-black/80 to-transparent">
          <p className="text-white text-center">{story.caption}</p>
        </div>
      )}
    </div>
  );
};

export default Stories;
