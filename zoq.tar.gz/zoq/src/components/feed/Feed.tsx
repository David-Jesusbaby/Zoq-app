'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Heart, MessageCircle, Repeat2, Share2, MoreHorizontal, Trash2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import Avatar from '@/components/ui/Avatar';
import { Post } from '@/types';
import { cn } from '@/utils/cn';

interface FeedProps {
  onCreatePost?: () => void;
}

const Feed = ({ onCreatePost }: FeedProps) => {
  const { user, isAuthenticated } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [commentingOn, setCommentingOn] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');

  const fetchPosts = useCallback(async (pageNum: number = 1) => {
    try {
      const response = await fetch(`/api/posts?page=${pageNum}&limit=10`);
      if (response.ok) {
        const data = await response.json();
        if (pageNum === 1) {
          setPosts(data.posts);
        } else {
          setPosts((prev) => [...prev, ...data.posts]);
        }
        setHasMore(data.pagination.hasMore);
      }
    } catch (error) {
      console.error('Failed to fetch posts:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);

  const handleLike = async (postId: string) => {
    if (!isAuthenticated) return;

    const token = localStorage.getItem('zoq_token');
    try {
      const response = await fetch(`/api/posts/${postId}/like`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setPosts((prev) =>
          prev.map((post) =>
            post._id === postId
              ? {
                  ...post,
                  likes: data.message === 'Post liked'
                    ? [...post.likes, user?.id || '']
                    : post.likes.filter((id) => id !== user?.id),
                }
              : post
          )
        );
      }
    } catch (error) {
      console.error('Failed to like post:', error);
    }
  };

  const handleComment = async (postId: string) => {
    if (!commentText.trim() || !isAuthenticated) return;

    const token = localStorage.getItem('zoq_token');
    try {
      const response = await fetch(`/api/posts/${postId}/comment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ content: commentText }),
      });

      if (response.ok) {
        const data = await response.json();
        setPosts((prev) =>
          prev.map((post) =>
            post._id === postId ? { ...post, comments: data.comments } : post
          )
        );
        setCommentText('');
        setCommentingOn(null);
      }
    } catch (error) {
      console.error('Failed to comment:', error);
    }
  };

  const handleDelete = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this post?')) return;

    const token = localStorage.getItem('zoq_token');
    try {
      const response = await fetch(`/api/posts/${postId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        setPosts((prev) => prev.filter((post) => post._id !== postId));
      }
    } catch (error) {
      console.error('Failed to delete post:', error);
    }
  };

  const loadMore = () => {
    if (!hasMore || loading) return;
    const nextPage = page + 1;
    setPage(nextPage);
    fetchPosts(nextPage);
  };

  if (loading && posts.length === 0) {
    return (
      <div className="space-y-4 p-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-neutral-900 rounded-2xl p-4 animate-pulse">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-neutral-800 rounded-full" />
              <div className="flex-1">
                <div className="h-4 bg-neutral-800 rounded w-1/3 mb-2" />
                <div className="h-3 bg-neutral-800 rounded w-1/4" />
              </div>
            </div>
            <div className="h-32 bg-neutral-800 rounded-xl" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4 p-4 pb-24 lg:pb-4">
      {posts.map((post) => (
        <PostCard
          key={post._id}
          post={post}
          currentUser={user}
          isAuthenticated={isAuthenticated}
          onLike={() => handleLike(post._id)}
          onComment={() => setCommentingOn(post._id)}
          onDelete={() => handleDelete(post._id)}
        />
      ))}

      {hasMore && (
        <button
          onClick={loadMore}
          className="w-full py-3 text-neutral-400 hover:text-white transition-colors"
        >
          Load more
        </button>
      )}

      {/* Comment Modal */}
      {commentingOn && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-end sm:items-center justify-center p-4">
          <div className="bg-neutral-900 rounded-2xl w-full max-w-lg overflow-hidden">
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
              <h3 className="font-semibold">Add Comment</h3>
              <button
                onClick={() => {
                  setCommentingOn(null);
                  setCommentText('');
                }}
                className="p-2 hover:bg-neutral-800 rounded-lg"
              >
                <span className="sr-only">Close</span>
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="p-4">
              <textarea
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Write a comment..."
                className="w-full px-4 py-3 rounded-xl bg-neutral-800 border border-neutral-700 text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#00d4ff] resize-none"
                rows={4}
                autoFocus
              />
              <button
                onClick={() => handleComment(commentingOn)}
                disabled={!commentText.trim()}
                className="w-full mt-4 py-3 bg-[#00d4ff] text-black font-semibold rounded-xl hover:bg-[#00d4ff]/90 transition-colors disabled:opacity-50"
              >
                Post Comment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface PostCardProps {
  post: Post;
  currentUser: ReturnType<typeof useAuth>['user'];
  isAuthenticated: boolean;
  onLike: () => void;
  onComment: () => void;
  onDelete: () => void;
}

const PostCard = ({
  post,
  currentUser,
  isAuthenticated,
  onLike,
  onComment,
  onDelete,
}: PostCardProps) => {
  const [showOptions, setShowOptions] = useState(false);
  const [showComments, setShowComments] = useState(false);

  const isLiked = currentUser ? post.likes.includes(currentUser.id) : false;
  const isOwner = currentUser?.id === post.author.id;

  return (
    <article className="bg-neutral-900 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <Avatar
            src={post.author.avatar}
            name={post.author.name}
            size="sm"
          />
          <div>
            <p className="font-medium text-white">{post.author.name}</p>
            <p className="text-xs text-neutral-500">@{post.author.username}</p>
          </div>
        </div>

        {isOwner && (
          <div className="relative">
            <button
              onClick={() => setShowOptions(!showOptions)}
              className="p-2 hover:bg-neutral-800 rounded-lg transition-colors"
            >
              <MoreHorizontal size={20} className="text-neutral-400" />
            </button>

            {showOptions && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setShowOptions(false)}
                />
                <div className="absolute right-0 top-full mt-1 w-40 bg-neutral-800 rounded-xl shadow-xl z-50 overflow-hidden">
                  <button
                    onClick={() => {
                      onDelete();
                      setShowOptions(false);
                    }}
                    className="flex items-center gap-2 w-full px-4 py-3 text-red-400 hover:bg-neutral-700 transition-colors"
                  >
                    <Trash2 size={16} />
                    <span>Delete</span>
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="px-4 pb-3">
        <p className="text-white whitespace-pre-wrap">{post.content}</p>
      </div>

      {/* Images */}
      {post.images.length > 0 && (
        <div className="px-4 pb-4">
          <div
            className={cn(
              'grid gap-2 rounded-xl overflow-hidden',
              post.images.length === 1 && 'grid-cols-1',
              post.images.length === 2 && 'grid-cols-2',
              post.images.length >= 3 && 'grid-cols-2'
            )}
          >
            {post.images.slice(0, 4).map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`Post image ${index + 1}`}
                className={cn(
                  'w-full object-cover',
                  post.images.length === 1 && 'aspect-video',
                  post.images.length > 1 && 'aspect-square'
                )}
              />
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between px-4 py-3 border-t border-neutral-800">
        <div className="flex items-center gap-6">
          <button
            onClick={onLike}
            disabled={!isAuthenticated}
            className={cn(
              'flex items-center gap-2 transition-colors',
              isLiked ? 'text-red-500' : 'text-neutral-400 hover:text-red-400'
            )}
          >
            <Heart
              size={20}
              fill={isLiked ? 'currentColor' : 'none'}
              className={cn(isLiked && 'animate-pulse')}
            />
            <span className="text-sm">{post.likes.length}</span>
          </button>

          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-2 text-neutral-400 hover:text-[#00d4ff] transition-colors"
          >
            <MessageCircle size={20} />
            <span className="text-sm">{post.comments.length}</span>
          </button>

          <button
            disabled={!isAuthenticated}
            className="flex items-center gap-2 text-neutral-400 hover:text-green-400 transition-colors"
          >
            <Repeat2 size={20} />
            <span className="text-sm">{post.reposts.length}</span>
          </button>
        </div>

        <button
          disabled={!isAuthenticated}
          className="text-neutral-400 hover:text-white transition-colors"
        >
          <Share2 size={20} />
        </button>
      </div>

      {/* Comments */}
      {showComments && post.comments.length > 0 && (
        <div className="px-4 pb-4 space-y-3">
          {post.comments.map((comment, index) => (
            <div key={index} className="flex gap-3">
              <Avatar
                src={comment.user.avatar}
                name={comment.user.name}
                size="xs"
              />
              <div className="flex-1 bg-neutral-800 rounded-xl px-3 py-2">
                <p className="text-sm font-medium text-white">
                  {comment.user.name}
                </p>
                <p className="text-sm text-neutral-300">{comment.content}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </article>
  );
};

export default Feed;
