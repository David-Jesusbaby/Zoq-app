'use client';

import React, { useState, useRef } from 'react';
import { X, Image, Loader2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import Avatar from '@/components/ui/Avatar';
import { cn } from '@/utils/cn';

interface CreatePostProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

const CreatePost = ({ isOpen, onClose, onSuccess }: CreatePostProps) => {
  const { user, isAuthenticated } = useAuth();
  const [content, setContent] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleSubmit = async () => {
    if (!content.trim() && images.length === 0) return;

    setIsSubmitting(true);
    const token = localStorage.getItem('zoq_token');

    try {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          content,
          images,
        }),
      });

      if (response.ok) {
        setContent('');
        setImages([]);
        onClose();
        onSuccess?.();
      }
    } catch (error) {
      console.error('Failed to create post:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImages((prev) => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
        <div className="bg-neutral-900 rounded-2xl p-6 max-w-sm w-full text-center">
          <p className="text-white mb-4">Please login to create a post</p>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#00d4ff] text-black font-medium rounded-xl"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-neutral-900 rounded-2xl w-full max-w-lg overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-800">
          <h3 className="text-lg font-semibold">Create Post</h3>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="p-2 hover:bg-neutral-800 rounded-lg transition-colors disabled:opacity-50"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4">
          <div className="flex gap-3 mb-4">
            <Avatar src={user?.avatar} name={user?.name || ''} size="md" />
            <div className="flex-1">
              <p className="font-medium text-white">{user?.name}</p>
              <p className="text-sm text-neutral-500">@{user?.username}</p>
            </div>
          </div>

          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="What's on your mind?"
            className="w-full px-4 py-3 rounded-xl bg-neutral-800 border border-neutral-700 text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#00d4ff] resize-none min-h-[120px]"
            maxLength={2000}
            autoFocus
          />

          {/* Image Preview */}
          {images.length > 0 && (
            <div className="flex gap-2 mt-4 overflow-x-auto hide-scrollbar">
              {images.map((image, index) => (
                <div key={index} className="relative flex-shrink-0">
                  <img
                    src={image}
                    alt={`Preview ${index + 1}`}
                    className="w-24 h-24 object-cover rounded-xl"
                  />
                  <button
                    onClick={() => removeImage(index)}
                    className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white hover:bg-red-600 transition-colors"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-4 border-t border-neutral-800">
          <div className="flex items-center gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={images.length >= 4 || isSubmitting}
              className="p-2 text-neutral-400 hover:text-[#00d4ff] hover:bg-neutral-800 rounded-lg transition-colors disabled:opacity-50"
            >
              <Image size={20} />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageSelect}
              className="hidden"
            />
            <span className="text-sm text-neutral-500">
              {images.length}/4 images
            </span>
          </div>

          <button
            onClick={handleSubmit}
            disabled={(!content.trim() && images.length === 0) || isSubmitting}
            className={cn(
              'px-6 py-2 bg-[#00d4ff] text-black font-semibold rounded-xl',
              'hover:bg-[#00d4ff]/90 transition-colors',
              'disabled:opacity-50 disabled:cursor-not-allowed',
              'flex items-center gap-2'
            )}
          >
            {isSubmitting ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                Posting...
              </>
            ) : (
              'Post'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreatePost;
