'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Plus, Bell, LogOut } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import Avatar from '@/components/ui/Avatar';
import { cn } from '@/utils/cn';

interface TopBarProps {
  onCreatePost?: () => void;
  unreadNotifications?: number;
}

const TopBar = ({ onCreatePost, unreadNotifications = 0 }: TopBarProps) => {
  const { user, logout, isAuthenticated } = useAuth();
  const [showDropdown, setShowDropdown] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-neutral-800">
      <div className="flex items-center justify-between h-14 px-4 max-w-7xl mx-auto">
        {/* Left: Create Post Button */}
        <button
          onClick={onCreatePost}
          className={cn(
            'flex items-center justify-center w-10 h-10 rounded-xl',
            'bg-neutral-800 hover:bg-neutral-700 transition-colors',
            'text-white'
          )}
        >
          <Plus size={20} />
        </button>

        {/* Center: Logo */}
        <Link href="/" className="absolute left-1/2 -translate-x-1/2">
          <h1 className="text-2xl font-bold gradient-text">ZOQ</h1>
        </Link>

        {/* Right: Notifications & Profile */}
        <div className="flex items-center gap-3">
          {/* Notifications */}
          <Link
            href="/notifications"
            className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-neutral-800 hover:bg-neutral-700 transition-colors"
          >
            <Bell size={20} className="text-neutral-300" />
            {unreadNotifications > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#00d4ff] text-black text-xs font-bold rounded-full flex items-center justify-center">
                {unreadNotifications > 9 ? '9+' : unreadNotifications}
              </span>
            )}
          </Link>

          {/* Profile Dropdown */}
          {isAuthenticated && user ? (
            <div className="relative">
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="flex items-center gap-2"
              >
                <Avatar
                  src={user.avatar}
                  name={user.name}
                  size="sm"
                />
              </button>

              {showDropdown && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowDropdown(false)}
                  />
                  <div className="absolute right-0 top-full mt-2 w-48 bg-neutral-900 border border-neutral-800 rounded-xl shadow-xl z-50 overflow-hidden">
                    <Link
                      href={`/profile/${user.username}`}
                      className="flex items-center gap-3 px-4 py-3 hover:bg-neutral-800 transition-colors"
                      onClick={() => setShowDropdown(false)}
                    >
                      <Avatar src={user.avatar} name={user.name} size="sm" />
                      <div>
                        <p className="font-medium text-white">{user.name}</p>
                        <p className="text-sm text-neutral-500">@{user.username}</p>
                      </div>
                    </Link>
                    <div className="border-t border-neutral-800">
                      <button
                        onClick={() => {
                          logout();
                          setShowDropdown(false);
                        }}
                        className="flex items-center gap-2 w-full px-4 py-3 text-red-400 hover:bg-neutral-800 transition-colors"
                      >
                        <LogOut size={18} />
                        <span>Logout</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          ) : (
            <Link
              href="/login"
              className="px-4 py-2 bg-[#00d4ff] text-black font-medium rounded-xl hover:bg-[#00d4ff]/90 transition-colors"
            >
              Login
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};

export default TopBar;
