'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Search, PlayCircle, MessageCircle, User } from 'lucide-react';
import { cn } from '@/utils/cn';

const navItems = [
  { href: '/', icon: Home, label: 'Home' },
  { href: '/search', icon: Search, label: 'Search' },
  { href: '/updates', icon: PlayCircle, label: 'Updates' },
  { href: '/messages', icon: MessageCircle, label: 'Inbox' },
  { href: '/profile', icon: User, label: 'Profile' },
];

const BottomNav = () => {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 glass border-t border-neutral-800 pb-safe lg:hidden">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex flex-col items-center justify-center flex-1 h-full',
                'transition-colors duration-200',
                isActive ? 'text-[#00d4ff]' : 'text-neutral-500 hover:text-neutral-300'
              )}
            >
              <item.icon
                size={24}
                strokeWidth={isActive ? 2.5 : 2}
                className={cn(isActive && 'glow-cyan')}
              />
              <span className="text-[10px] mt-0.5">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
