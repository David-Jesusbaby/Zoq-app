import { Server as NetServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import { verifyToken } from '@/lib/auth/jwt';

export const config = {
  api: {
    bodyParser: false,
  },
};

let io: SocketIOServer | null = null;

export function getIO(): SocketIOServer | null {
  return io;
}

export function initSocketServer(server: NetServer): SocketIOServer {
  if (io) {
    return io;
  }

  io = new SocketIOServer(server, {
    path: '/api/socket',
    addTrailingSlash: false,
    cors: {
      origin: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
      methods: ['GET', 'POST'],
      credentials: true,
    },
  });

  // Store connected users
  const connectedUsers = new Map<string, string>(); // userId -> socketId

  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    
    if (!token) {
      return next(new Error('Authentication error'));
    }

    try {
      const decoded = verifyToken(token);
      socket.data.userId = decoded.userId;
      socket.data.username = decoded.username;
      next();
    } catch (error) {
      next(new Error('Authentication error'));
    }
  });

  io.on('connection', (socket) => {
    const userId = socket.data.userId;
    const username = socket.data.username;

    console.log(`User connected: ${username} (${userId})`);
    connectedUsers.set(userId, socket.id);

    // Join personal room for notifications
    socket.join(`user:${userId}`);

    // Handle typing status in chat
    socket.on('typing', ({ recipientId, isTyping }) => {
      const recipientSocketId = connectedUsers.get(recipientId);
      if (recipientSocketId) {
        io?.to(recipientSocketId).emit('typing', {
          userId,
          username,
          isTyping,
        });
      }
    });

    // Handle private messages
    socket.on('send_message', (data) => {
      const { recipientId, content } = data;
      const recipientSocketId = connectedUsers.get(recipientId);

      // Emit to recipient if online
      if (recipientSocketId) {
        io?.to(recipientSocketId).emit('new_message', {
          senderId: userId,
          senderName: username,
          content,
          createdAt: new Date(),
        });
      }

      // Emit back to sender
      socket.emit('message_sent', {
        recipientId,
        content,
        createdAt: new Date(),
      });
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log(`User disconnected: ${username} (${userId})`);
      connectedUsers.delete(userId);
    });
  });

  return io;
}

// Helper function to emit notifications
export function emitNotification(userId: string, notification: unknown) {
  if (io) {
    io.to(`user:${userId}`).emit('notification', notification);
  }
}

// Helper function to emit new posts to feed
export function emitNewPost(post: unknown) {
  if (io) {
    io.emit('new_post', post);
  }
}
