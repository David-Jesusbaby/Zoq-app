'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, Heart, MessageCircle, UserPlus, Check, Repeat2, AtSign } from 'lucide-react';
import BottomNav from '@/components/layout/BottomNav';
import Avatar from '@/components/ui/Avatar';
import { Notification } from '@/types';
import { cn } from '@/utils/cn';

export default function Notifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    const token = localStorage.getItem('zoq_token');
    if (!token) return;

    try {
      const response = await fetch('/api/notifications', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setNotifications(data.notifications);
        setUnreadCount(data.unreadCount);
      }
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAllAsRead = async () => {
    const token = localStorage.getItem('zoq_token');
    if (!token) return;

    try {
      const response = await fetch('/api/notifications', {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        setNotifications((prev) =>
          prev.map((n) => ({ ...n, isRead: true }))
        );
        setUnreadCount(0);
      }
    } catch (error) {
      console.error('Failed to mark notifications as read:', error);
    }
  };

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'like':
        return <Heart size={18} className="text-red-500" fill="currentColor" />;
      case 'comment':
        return <MessageCircle size={18} className="text-[#00d4ff]" />;
      case 'connection_request':
      case 'connection_accepted':
        return <UserPlus size={18} className="text-green-500" />;
      case 'repost':
        return <Repeat2 size={18} className="text-green-500" />;
      case 'mention':
        return <AtSign size={18} className="text-purple-500" />;
      default:
        return null;
    }
  };

  return (
    <main className="min-h-screen bg-black pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 glass border-b border-neutral-800">
        <div className="flex items-center justify-between h-14 px-4">
          <div className="flex items-center gap-4">
            <Link
              href="/"
              className="p-2 hover:bg-neutral-800 rounded-lg transition-colors"
            >
              <ArrowLeft size={20} />
            </Link>
            <h1 className="text-lg font-semibold">Notifications</h1>
          </div>
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="text-sm text-[#00d4ff] hover:underline"
            >
              Mark all read
            </button>
          )}
        </div>
      </div>

      {/* Notifications List */}
      <div className="divide-y divide-neutral-800">
        {loading ? (
          <div className="space-y-4 p-4">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="flex items-center gap-3 p-3 animate-pulse"
              >
                <div className="w-10 h-10 bg-neutral-800 rounded-full" />
                <div className="flex-1">
                  <div className="h-4 bg-neutral-800 rounded w-3/4 mb-2" />
                  <div className="h-3 bg-neutral-800 rounded w-1/4" />
                </div>
              </div>
            ))}
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-neutral-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check size={32} className="text-neutral-500" />
            </div>
            <p className="text-neutral-400">No notifications yet</p>
          </div>
        ) : (
          notifications.map((notification) => (
            <Link
              key={notification._id}
              href={
                notification.post
                  ? `/post/${notification.post._id}`
                  : `/profile/${notification.sender.username}`
              }
              className={cn(
                'flex items-start gap-3 p-4 hover:bg-neutral-900 transition-colors',
                !notification.isRead && 'bg-neutral-900/50'
              )}
            >
              <div className="relative">
                <Avatar
                  src={notification.sender.avatar}
                  name={notification.sender.name}
                  size="md"
                />
                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-neutral-900 rounded-full flex items-center justify-center">
                  {getNotificationIcon(notification.type)}
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <p className="text-white">
                  <span className="font-medium">{notification.sender.name}</span>{' '}
                  <span className="text-neutral-400">
                    {notification.message.replace(
                      notification.sender.name,
                      ''
                    )}
                  </span>
                </p>
                <p className="text-sm text-neutral-500 mt-1">
                  {new Date(notification.createdAt).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>
              </div>

              {!notification.isRead && (
                <div className="w-2 h-2 bg-[#00d4ff] rounded-full mt-2" />
              )}
            </Link>
          ))
        )}
      </div>

      <BottomNav />
    </main>
  );
}
