import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db/mongodb';
import Connection from '@/models/Connection';
import User from '@/models/User';
import Notification from '@/models/Notification';
import { verifyToken } from '@/lib/auth/jwt';

// Get user's connections
export async function GET(req: NextRequest) {
  try {
    await connectDB();

    // Get token from header
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);

    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status') || 'accepted';

    let connections;
    if (status === 'pending') {
      // Get pending requests sent TO the user
      connections = await Connection.find({
        recipient: decoded.userId,
        status: 'pending',
      })
        .populate('requester', 'name username avatar bio')
        .sort({ createdAt: -1 });
    } else {
      // Get accepted connections
      connections = await Connection.find({
        $or: [
          { requester: decoded.userId, status: 'accepted' },
          { recipient: decoded.userId, status: 'accepted' },
        ],
      })
        .populate('requester', 'name username avatar')
        .populate('recipient', 'name username avatar')
        .sort({ createdAt: -1 });
    }

    return NextResponse.json({ connections }, { status: 200 });
  } catch (error) {
    console.error('Get connections error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Send connection request
export async function POST(req: NextRequest) {
  try {
    await connectDB();

    // Get token from header
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);

    const body = await req.json();
    const { userId } = body;

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Check if trying to connect to self
    if (userId === decoded.userId) {
      return NextResponse.json(
        { error: 'Cannot connect to yourself' },
        { status: 400 }
      );
    }

    // Check if connection already exists
    const existingConnection = await Connection.findOne({
      $or: [
        { requester: decoded.userId, recipient: userId },
        { requester: userId, recipient: decoded.userId },
      ],
    });

    if (existingConnection) {
      return NextResponse.json(
        { error: 'Connection request already exists' },
        { status: 409 }
      );
    }

    // Create connection request
    const connection = await Connection.create({
      requester: decoded.userId,
      recipient: userId,
      status: 'pending',
    });

    // Create notification
    await Notification.create({
      recipient: userId,
      sender: decoded.userId,
      type: 'connection_request',
      message: `${decoded.username} sent you a connection request`,
    });

    await connection.populate('requester', 'name username avatar');
    await connection.populate('recipient', 'name username avatar');

    return NextResponse.json(
      { message: 'Connection request sent', connection },
      { status: 201 }
    );
  } catch (error) {
    console.error('Send connection error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
