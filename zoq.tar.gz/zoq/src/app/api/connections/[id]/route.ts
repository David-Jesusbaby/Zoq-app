import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db/mongodb';
import Connection from '@/models/Connection';
import User from '@/models/User';
import Notification from '@/models/Notification';
import { verifyToken } from '@/lib/auth/jwt';

// Accept or reject connection request
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectDB();

    // Get token from header
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);
    const connectionId = params.id;

    const body = await req.json();
    const { status } = body;

    if (!status || !['accepted', 'rejected'].includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status. Must be accepted or rejected' },
        { status: 400 }
      );
    }

    const connection = await Connection.findById(connectionId);

    if (!connection) {
      return NextResponse.json(
        { error: 'Connection request not found' },
        { status: 404 }
      );
    }

    // Verify the current user is the recipient
    if (connection.recipient.toString() !== decoded.userId) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    // Update connection status
    connection.status = status;
    await connection.save();

    if (status === 'accepted') {
      // Add to each user's connections list
      await User.findByIdAndUpdate(decoded.userId, {
        $addToSet: { connections: connection.requester },
      });
      await User.findByIdAndUpdate(connection.requester, {
        $addToSet: { connections: decoded.userId },
      });

      // Create notification
      await Notification.create({
        recipient: connection.requester,
        sender: decoded.userId,
        type: 'connection_accepted',
        message: `${decoded.username} accepted your connection request`,
      });
    }

    return NextResponse.json(
      { message: `Connection request ${status}`, connection },
      { status: 200 }
    );
  } catch (error) {
    console.error('Update connection error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Remove connection
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectDB();

    // Get token from header
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);
    const connectionId = params.id;

    const connection = await Connection.findById(connectionId);

    if (!connection) {
      return NextResponse.json(
        { error: 'Connection not found' },
        { status: 404 }
      );
    }

    // Verify the current user is part of the connection
    if (
      connection.requester.toString() !== decoded.userId &&
      connection.recipient.toString() !== decoded.userId
    ) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    // Remove from users' connections lists
    await User.findByIdAndUpdate(connection.requester, {
      $pull: { connections: connection.recipient },
    });
    await User.findByIdAndUpdate(connection.recipient, {
      $pull: { connections: connection.requester },
    });

    // Delete connection
    await Connection.findByIdAndDelete(connectionId);

    return NextResponse.json(
      { message: 'Connection removed' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Delete connection error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
