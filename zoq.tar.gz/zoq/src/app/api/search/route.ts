import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db/mongodb';
import User from '@/models/User';
import Post from '@/models/Post';

export async function GET(req: NextRequest) {
  try {
    await connectDB();

    const { searchParams } = new URL(req.url);
    const q = searchParams.get('q');
    const type = searchParams.get('type') || 'all'; // all, users, posts
    const skill = searchParams.get('skill');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const skip = (page - 1) * limit;

    if (!q && !skill) {
      return NextResponse.json(
        { error: 'Search query or skill filter is required' },
        { status: 400 }
      );
    }

    const results: {
      users?: unknown[];
      posts?: unknown[];
      pagination: { page: number; limit: number; total: number; hasMore: boolean };
    } = {
      pagination: { page, limit, total: 0, hasMore: false },
    };

    // Search users
    if (type === 'all' || type === 'users') {
      const userQuery: Record<string, unknown> = {};
      
      if (q) {
        userQuery.$or = [
          { name: { $regex: q, $options: 'i' } },
          { username: { $regex: q, $options: 'i' } },
          { bio: { $regex: q, $options: 'i' } },
        ];
      }
      
      if (skill) {
        userQuery.skills = { $in: [new RegExp(skill, 'i')] };
      }

      const users = await User.find(userQuery)
        .select('-password -email')
        .skip(skip)
        .limit(limit)
        .sort({ followers: -1 });

      const totalUsers = await User.countDocuments(userQuery);

      results.users = users;
      results.pagination.total += totalUsers;
    }

    // Search posts
    if (type === 'all' || type === 'posts') {
      const postQuery: Record<string, unknown> = {};
      
      if (q) {
        postQuery.$text = { $search: q };
      }

      const posts = await Post.find(postQuery)
        .populate('author', 'name username avatar')
        .skip(skip)
        .limit(limit)
        .sort({ createdAt: -1 });

      const totalPosts = await Post.countDocuments(postQuery);

      results.posts = posts;
      results.pagination.total += totalPosts;
    }

    results.pagination.hasMore = skip + limit < results.pagination.total;

    return NextResponse.json(results, { status: 200 });
  } catch (error) {
    console.error('Search error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
