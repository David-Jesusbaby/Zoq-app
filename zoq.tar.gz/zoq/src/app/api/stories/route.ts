import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db/mongodb';
import Story from '@/models/Story';
import { verifyToken } from '@/lib/auth/jwt';

// Get active stories
export async function GET(req: NextRequest) {
  try {
    await connectDB();

    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId');

    const query: Record<string, unknown> = {
      expiresAt: { $gt: new Date() },
    };

    if (userId) {
      query.author = userId;
    }

    const stories = await Story.find(query)
      .sort({ createdAt: -1 })
      .populate('author', 'name username avatar')
      .populate('viewers.user', 'name username avatar');

    return NextResponse.json({ stories }, { status: 200 });
  } catch (error) {
    console.error('Get stories error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Create a new story
export async function POST(req: NextRequest) {
  try {
    await connectDB();

    // Get token from header
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);

    const body = await req.json();
    const { image, caption } = body;

    if (!image) {
      return NextResponse.json(
        { error: 'Image is required' },
        { status: 400 }
      );
    }

    // Set expiration to 24 hours from now
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    const story = await Story.create({
      author: decoded.userId,
      image,
      caption,
      expiresAt,
    });

    await story.populate('author', 'name username avatar');

    return NextResponse.json(
      { message: 'Story created successfully', story },
      { status: 201 }
    );
  } catch (error) {
    console.error('Create story error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
