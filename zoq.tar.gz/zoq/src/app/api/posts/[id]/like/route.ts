import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db/mongodb';
import Post from '@/models/Post';
import Notification from '@/models/Notification';
import { verifyToken } from '@/lib/auth/jwt';

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectDB();

    // Get token from header
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);
    const postId = params.id;

    const post = await Post.findById(postId);

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Check if user already liked the post
    const alreadyLiked = post.likes.includes(decoded.userId as unknown as mongoose.Types.ObjectId);

    if (alreadyLiked) {
      // Unlike
      post.likes = post.likes.filter(
        (id) => id.toString() !== decoded.userId
      );
    } else {
      // Like
      post.likes.push(decoded.userId as unknown as mongoose.Types.ObjectId);

      // Create notification (if not liking own post)
      if (post.author.toString() !== decoded.userId) {
        await Notification.create({
          recipient: post.author,
          sender: decoded.userId,
          type: 'like',
          post: postId,
          message: `${decoded.username} liked your post`,
        });
      }
    }

    await post.save();

    return NextResponse.json(
      {
        message: alreadyLiked ? 'Post unliked' : 'Post liked',
        likes: post.likes.length,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Like post error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
