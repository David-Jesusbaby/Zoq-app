import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db/mongodb';
import Post from '@/models/Post';
import Notification from '@/models/Notification';
import { verifyToken } from '@/lib/auth/jwt';

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectDB();

    // Get token from header
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);
    const postId = params.id;

    const body = await req.json();
    const { content } = body;

    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'Comment content is required' },
        { status: 400 }
      );
    }

    const post = await Post.findById(postId);

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Add comment
    post.comments.push({
      user: decoded.userId as unknown as mongoose.Types.ObjectId,
      content,
      createdAt: new Date(),
    });

    await post.save();

    // Create notification (if not commenting on own post)
    if (post.author.toString() !== decoded.userId) {
      await Notification.create({
        recipient: post.author,
        sender: decoded.userId,
        type: 'comment',
        post: postId,
        message: `${decoded.username} commented on your post`,
      });
    }

    await post.populate('comments.user', 'name username avatar');

    return NextResponse.json(
      {
        message: 'Comment added successfully',
        comments: post.comments,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Comment post error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
