import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db/mongodb';
import Post from '@/models/Post';
import Notification from '@/models/Notification';
import { verifyToken } from '@/lib/auth/jwt';

// Get feed posts
export async function GET(req: NextRequest) {
  try {
    await connectDB();

    const { searchParams } = new URL(req.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const skip = (page - 1) * limit;

    const posts = await Post.find()
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('author', 'name username avatar')
      .populate('originalPost')
      .populate({
        path: 'originalPost',
        populate: {
          path: 'author',
          select: 'name username avatar',
        },
      })
      .populate('comments.user', 'name username avatar');

    const total = await Post.countDocuments();

    return NextResponse.json(
      {
        posts,
        pagination: {
          page,
          limit,
          total,
          hasMore: skip + posts.length < total,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Get posts error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Create a new post
export async function POST(req: NextRequest) {
  try {
    await connectDB();

    // Get token from header
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);

    const body = await req.json();
    const { content, images } = body;

    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'Post content is required' },
        { status: 400 }
      );
    }

    const post = await Post.create({
      author: decoded.userId,
      content,
      images: images || [],
    });

    await post.populate('author', 'name username avatar');

    return NextResponse.json(
      { message: 'Post created successfully', post },
      { status: 201 }
    );
  } catch (error) {
    console.error('Create post error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
