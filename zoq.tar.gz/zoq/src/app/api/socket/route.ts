import { NextRequest } from 'next/server';
import { getIO } from '@/lib/socket/server';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const io = getIO();
  
  if (!io) {
    return new Response('Socket.IO not initialized', { status: 500 });
  }

  return new Response('Socket.IO is running', { status: 200 });
}
