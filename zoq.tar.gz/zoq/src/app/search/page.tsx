'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { Search, X, Filter } from 'lucide-react';
import BottomNav from '@/components/layout/BottomNav';
import Avatar from '@/components/ui/Avatar';
import { User, Post } from '@/types';
import { cn } from '@/utils/cn';

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'users' | 'posts'>('all');
  const [users, setUsers] = useState<User[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(false);

  const search = useCallback(async () => {
    if (!query.trim()) {
      setUsers([]);
      setPosts([]);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `/api/search?q=${encodeURIComponent(query)}&type=${activeTab}`
      );
      if (response.ok) {
        const data = await response.json();
        setUsers(data.users || []);
        setPosts(data.posts || []);
      }
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setLoading(false);
    }
  }, [query, activeTab]);

  useEffect(() => {
    const timeout = setTimeout(search, 300);
    return () => clearTimeout(timeout);
  }, [search]);

  return (
    <main className="min-h-screen bg-black pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 glass border-b border-neutral-800">
        <div className="p-4">
          <div className="relative">
            <Search
              size={20}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500"
            />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search users, posts, skills..."
              className="w-full pl-12 pr-10 py-3 bg-neutral-900 border border-neutral-800 rounded-xl text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#00d4ff]"
              autoFocus
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-neutral-800 rounded-full transition-colors"
              >
                <X size={16} className="text-neutral-500" />
              </button>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-neutral-800">
          {(['all', 'users', 'posts'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                'flex-1 py-3 text-sm font-medium capitalize transition-colors relative',
                activeTab === tab
                  ? 'text-[#00d4ff]'
                  : 'text-neutral-400 hover:text-white'
              )}
            >
              {tab}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#00d4ff]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="p-4">
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-20 bg-neutral-900 rounded-xl animate-pulse"
              />
            ))}
          </div>
        ) : !query ? (
          <div className="text-center py-12">
            <Search size={48} className="mx-auto text-neutral-600 mb-4" />
            <p className="text-neutral-400">Search for users, posts, or skills</p>
          </div>
        ) : users.length === 0 && posts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-neutral-400">No results found for "{query}"</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Users */}
            {(activeTab === 'all' || activeTab === 'users') &&
              users.length > 0 && (
                <div>
                  {activeTab === 'all' && (
                    <h3 className="text-sm font-medium text-neutral-400 mb-3">
                      Users
                    </h3>
                  )}
                  <div className="space-y-2">
                    {users.map((user) => (
                      <Link
                        key={user.id}
                        href={`/profile/${user.username}`}
                        className="flex items-center gap-3 p-3 bg-neutral-900 rounded-xl hover:bg-neutral-800 transition-colors"
                      >
                        <Avatar
                          src={user.avatar}
                          name={user.name}
                          size="md"
                        />
                        <div className="flex-1">
                          <p className="font-medium text-white">{user.name}</p>
                          <p className="text-sm text-neutral-500">
                            @{user.username}
                          </p>
                          {user.bio && (
                            <p className="text-sm text-neutral-400 line-clamp-1 mt-1">
                              {user.bio}
                            </p>
                          )}
                        </div>
                        {user.skills.slice(0, 2).map((skill, i) => (
                          <span
                            key={i}
                            className="px-2 py-1 bg-neutral-800 text-neutral-300 text-xs rounded-full"
                          >
                            {skill}
                          </span>
                        ))}
                      </Link>
                    ))}
                  </div>
                </div>
              )}

            {/* Posts */}
            {(activeTab === 'all' || activeTab === 'posts') &&
              posts.length > 0 && (
                <div>
                  {activeTab === 'all' && (
                    <h3 className="text-sm font-medium text-neutral-400 mb-3">
                      Posts
                    </h3>
                  )}
                  <div className="space-y-4">
                    {posts.map((post) => (
                      <Link
                        key={post._id}
                        href={`/post/${post._id}`}
                        className="block p-4 bg-neutral-900 rounded-xl hover:bg-neutral-800 transition-colors"
                      >
                        <div className="flex items-center gap-3 mb-3">
                          <Avatar
                            src={post.author.avatar}
                            name={post.author.name}
                            size="sm"
                          />
                          <div>
                            <p className="font-medium text-white">
                              {post.author.name}
                            </p>
                            <p className="text-xs text-neutral-500">
                              @{post.author.username}
                            </p>
                          </div>
                        </div>
                        <p className="text-neutral-300 line-clamp-3">
                          {post.content}
                        </p>
                        {post.images.length > 0 && (
                          <div className="flex gap-2 mt-3">
                            {post.images.slice(0, 3).map((img, i) => (
                              <img
                                key={i}
                                src={img}
                                alt=""
                                className="w-20 h-20 object-cover rounded-lg"
                              />
                            ))}
                            {post.images.length > 3 && (
                              <div className="w-20 h-20 bg-neutral-800 rounded-lg flex items-center justify-center text-neutral-400">
                                +{post.images.length - 3}
                              </div>
                            )}
                          </div>
                        )}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
          </div>
        )}
      </div>

      <BottomNav />
    </main>
  );
}
