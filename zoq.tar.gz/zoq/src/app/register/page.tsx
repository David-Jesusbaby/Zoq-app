'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import { cn } from '@/utils/cn';

export default function Register() {
  const router = useRouter();
  const { register } = useAuth();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    username: '',
    name: '',
    role: 'geek' as 'geek' | 'company',
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleNext = () => {
    setError('');

    if (step === 1) {
      if (!formData.email || !formData.password || !formData.confirmPassword) {
        setError('Please fill in all fields');
        return;
      }
      if (formData.password !== formData.confirmPassword) {
        setError('Passwords do not match');
        return;
      }
      if (formData.password.length < 6) {
        setError('Password must be at least 6 characters');
        return;
      }
    }

    if (step === 2) {
      if (!formData.username || !formData.name) {
        setError('Please fill in all fields');
        return;
      }
    }

    setStep((prev) => prev + 1);
  };

  const handleBack = () => {
    setError('');
    setStep((prev) => prev - 1);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      await register({
        email: formData.email,
        password: formData.password,
        username: formData.username,
        name: formData.name,
        role: formData.role,
      });
      router.push('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  const updateField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <main className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">ZOQ</h1>
          <p className="text-neutral-400">Join the tech community</p>
        </div>

        {/* Progress */}
        <div className="flex gap-2 mb-6">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className={cn(
                'flex-1 h-1 rounded-full transition-colors',
                i <= step ? 'bg-[#00d4ff]' : 'bg-neutral-800'
              )}
            />
          ))}
        </div>

        {/* Form */}
        <div className="bg-neutral-900 rounded-2xl p-6 border border-neutral-800">
          {error && (
            <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-sm">
              {error}
            </div>
          )}

          {step === 1 && (
            <>
              <h2 className="text-xl font-semibold text-white mb-2">
                Create your account
              </h2>
              <p className="text-neutral-400 text-sm mb-6">
                Step 1: Account credentials
              </p>

              <div className="space-y-4">
                <Input
                  label="Email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  placeholder="Enter your email"
                />

                <Input
                  label="Password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => updateField('password', e.target.value)}
                  placeholder="Create a password"
                />

                <Input
                  label="Confirm Password"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => updateField('confirmPassword', e.target.value)}
                  placeholder="Confirm your password"
                />

                <Button onClick={handleNext} fullWidth>
                  Continue
                </Button>
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <h2 className="text-xl font-semibold text-white mb-2">
                Tell us about yourself
              </h2>
              <p className="text-neutral-400 text-sm mb-6">
                Step 2: Profile information
              </p>

              <div className="space-y-4">
                <Input
                  label="Full Name"
                  value={formData.name}
                  onChange={(e) => updateField('name', e.target.value)}
                  placeholder="Enter your full name"
                />

                <Input
                  label="Username"
                  value={formData.username}
                  onChange={(e) => updateField('username', e.target.value)}
                  placeholder="Choose a username"
                />

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={handleBack}
                    className="flex-1 py-3 border border-neutral-700 text-white rounded-xl hover:bg-neutral-800 transition-colors"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={handleNext}
                    className="flex-1 py-3 bg-[#00d4ff] text-black font-semibold rounded-xl hover:bg-[#00d4ff]/90 transition-colors"
                  >
                    Continue
                  </button>
                </div>
              </div>
            </>
          )}

          {step === 3 && (
            <>
              <h2 className="text-xl font-semibold text-white mb-2">
                What's your role?
              </h2>
              <p className="text-neutral-400 text-sm mb-6">
                Step 3: Select your profile type
              </p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => updateField('role', 'geek')}
                    className={cn(
                      'p-4 rounded-xl border-2 transition-all text-left',
                      formData.role === 'geek'
                        ? 'border-[#00d4ff] bg-[#00d4ff]/10'
                        : 'border-neutral-700 hover:border-neutral-600'
                    )}
                  >
                    <div className="text-2xl mb-2">👨‍💻</div>
                    <div className="font-medium text-white">Tech Geek</div>
                    <div className="text-xs text-neutral-400">
                      Developer, designer, or tech enthusiast
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => updateField('role', 'company')}
                    className={cn(
                      'p-4 rounded-xl border-2 transition-all text-left',
                      formData.role === 'company'
                        ? 'border-[#00d4ff] bg-[#00d4ff]/10'
                        : 'border-neutral-700 hover:border-neutral-600'
                    )}
                  >
                    <div className="text-2xl mb-2">🏢</div>
                    <div className="font-medium text-white">Company</div>
                    <div className="text-xs text-neutral-400">
                      Startup, agency, or organization
                    </div>
                  </button>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleBack}
                    className="flex-1 py-3 border border-neutral-700 text-white rounded-xl hover:bg-neutral-800 transition-colors"
                  >
                    Back
                  </button>
                  <Button
                    type="submit"
                    fullWidth
                    isLoading={isLoading}
                    className="flex-1"
                  >
                    Create Account
                  </Button>
                </div>
              </form>
            </>
          )}

          <div className="mt-6 text-center">
            <p className="text-neutral-400 text-sm">
              Already have an account?{' '}
              <Link
                href="/login"
                className="text-[#00d4ff] hover:underline font-medium"
              >
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}
