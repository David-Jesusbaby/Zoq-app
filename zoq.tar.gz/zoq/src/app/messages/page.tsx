'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, Search, MessageSquare } from 'lucide-react';
import BottomNav from '@/components/layout/BottomNav';
import Avatar from '@/components/ui/Avatar';
import { useAuth } from '@/context/AuthContext';
import { Message } from '@/types';

interface Conversation {
  user: {
    id: string;
    name: string;
    username: string;
    avatar?: string;
  };
  lastMessage: Message;
  unreadCount: number;
}

export default function Messages() {
  const { user, isAuthenticated } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchConversations();
  }, []);

  const fetchConversations = async () => {
    const token = localStorage.getItem('zoq_token');
    if (!token) return;

    try {
      // This would fetch from /api/messages/conversations
      // For now, we'll use mock data
      setConversations([
        {
          user: {
            id: '1',
            name: 'Sarah Chen',
            username: 'sarahchen',
            avatar: '',
          },
          lastMessage: {
            _id: '1',
            sender: { id: '1', name: 'Sarah Chen', username: 'sarahchen' } as any,
            recipient: { id: '2', name: 'John Doe', username: 'johndoe' } as any,
            content: 'Hey! Are you available for a quick call?',
            isRead: false,
            createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
          },
          unreadCount: 2,
        },
        {
          user: {
            id: '2',
            name: 'Alex Kumar',
            username: 'alexkumar',
            avatar: '',
          },
          lastMessage: {
            _id: '2',
            sender: { id: '2', name: 'Alex Kumar', username: 'alexkumar' } as any,
            recipient: { id: '1', name: 'John Doe', username: 'johndoe' } as any,
            content: 'Thanks for connecting! Love your work.',
            isRead: true,
            createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
          },
          unreadCount: 0,
        },
      ]);
    } catch (error) {
      console.error('Failed to fetch conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (date: string) => {
    const now = new Date();
    const messageDate = new Date(date);
    const diff = now.getTime() - messageDate.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    return messageDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  if (!isAuthenticated) {
    return (
      <main className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <MessageSquare size={48} className="mx-auto text-neutral-600 mb-4" />
          <p className="text-white mb-4">Please login to view messages</p>
          <Link
            href="/login"
            className="px-6 py-2 bg-[#00d4ff] text-black font-medium rounded-xl"
          >
            Login
          </Link>
        </div>
        <BottomNav />
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-black pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 glass border-b border-neutral-800">
        <div className="flex items-center justify-between h-14 px-4">
          <div className="flex items-center gap-4">
            <Link
              href="/"
              className="p-2 hover:bg-neutral-800 rounded-lg transition-colors"
            >
              <ArrowLeft size={20} />
            </Link>
            <h1 className="text-lg font-semibold">Messages</h1>
          </div>
          <button className="p-2 hover:bg-neutral-800 rounded-lg transition-colors">
            <Search size={20} />
          </button>
        </div>
      </div>

      {/* Conversations */}
      <div className="divide-y divide-neutral-800">
        {loading ? (
          <div className="space-y-4 p-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="flex items-center gap-3 p-3 animate-pulse"
              >
                <div className="w-12 h-12 bg-neutral-800 rounded-full" />
                <div className="flex-1">
                  <div className="h-4 bg-neutral-800 rounded w-1/3 mb-2" />
                  <div className="h-3 bg-neutral-800 rounded w-2/3" />
                </div>
              </div>
            ))}
          </div>
        ) : conversations.length === 0 ? (
          <div className="text-center py-12">
            <MessageSquare size={48} className="mx-auto text-neutral-600 mb-4" />
            <p className="text-neutral-400">No messages yet</p>
            <p className="text-sm text-neutral-500 mt-1">
              Start a conversation with someone
            </p>
          </div>
        ) : (
          conversations.map((conversation) => (
            <Link
              key={conversation.user.id}
              href={`/messages/${conversation.user.username}`}
              className="flex items-center gap-3 p-4 hover:bg-neutral-900 transition-colors"
            >
              <Avatar
                src={conversation.user.avatar}
                name={conversation.user.name}
                size="lg"
              />

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-white">
                    {conversation.user.name}
                  </p>
                  <span className="text-xs text-neutral-500">
                    {formatTime(conversation.lastMessage.createdAt)}
                  </span>
                </div>
                <p
                  className={`text-sm truncate ${
                    conversation.unreadCount > 0
                      ? 'text-white font-medium'
                      : 'text-neutral-400'
                  }`}
                >
                  {conversation.lastMessage.sender.id === user?.id
                    ? 'You: '
                    : ''}
                  {conversation.lastMessage.content}
                </p>
              </div>

              {conversation.unreadCount > 0 && (
                <div className="w-5 h-5 bg-[#00d4ff] rounded-full flex items-center justify-center text-xs text-black font-medium">
                  {conversation.unreadCount}
                </div>
              )}
            </Link>
          ))
        )}
      </div>

      <BottomNav />
    </main>
  );
}
