'use client';

import React, { useState } from 'react';
import TopBar from '@/components/layout/TopBar';
import BottomNav from '@/components/layout/BottomNav';
import Stories from '@/components/stories/Stories';
import Feed from '@/components/feed/Feed';
import CreatePost from '@/components/feed/CreatePost';

export default function Home() {
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [refreshFeed, setRefreshFeed] = useState(0);

  const handlePostSuccess = () => {
    setRefreshFeed((prev) => prev + 1);
  };

  return (
    <main className="min-h-screen bg-black">
      <TopBar
        onCreatePost={() => setIsCreatePostOpen(true)}
        unreadNotifications={0}
      />

      <div className="pt-14 max-w-2xl mx-auto">
        <Stories />
        <Feed key={refreshFeed} onCreatePost={() => setIsCreatePostOpen(true)} />
      </div>

      <BottomNav />

      <CreatePost
        isOpen={isCreatePostOpen}
        onClose={() => setIsCreatePostOpen(false)}
        onSuccess={handlePostSuccess}
      />
    </main>
  );
}
