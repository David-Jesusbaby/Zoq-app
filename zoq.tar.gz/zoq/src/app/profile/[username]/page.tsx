'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, MapPin, Link as LinkIcon, Briefcase, Users, UserPlus, UserCheck, MessageCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import Avatar from '@/components/ui/Avatar';
import BottomNav from '@/components/layout/BottomNav';
import { User } from '@/types';
import { cn } from '@/utils/cn';

export default function Profile() {
  const params = useParams();
  const { user: currentUser, isAuthenticated } = useAuth();
  const [profile, setProfile] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isConnected, setIsConnected] = useState(false);
  const [connectionPending, setConnectionPending] = useState(false);

  const username = params.username as string;
  const isOwnProfile = currentUser?.username === username;

  useEffect(() => {
    fetchProfile();
  }, [username]);

  const fetchProfile = async () => {
    try {
      const response = await fetch(`/api/users/${username}`);
      if (response.ok) {
        const data = await response.json();
        setProfile(data.user);
        // Check if connected
        if (currentUser) {
          setIsConnected(data.user.connections.includes(currentUser.id));
        }
      }
    } catch (error) {
      console.error('Failed to fetch profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async () => {
    if (!isAuthenticated || !profile) return;

    setConnectionPending(true);
    const token = localStorage.getItem('zoq_token');

    try {
      const response = await fetch('/api/connections', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ userId: profile.id }),
      });

      if (response.ok) {
        setIsConnected(true);
      }
    } catch (error) {
      console.error('Failed to send connection request:', error);
    } finally {
      setConnectionPending(false);
    }
  };

  if (loading) {
    return (
      <main className="min-h-screen bg-black">
        <div className="animate-pulse">
          <div className="h-48 bg-neutral-900" />
          <div className="px-4 -mt-16">
            <div className="w-32 h-32 bg-neutral-800 rounded-full border-4 border-black" />
            <div className="mt-4 h-6 bg-neutral-800 rounded w-1/3" />
            <div className="mt-2 h-4 bg-neutral-800 rounded w-1/4" />
          </div>
        </div>
        <BottomNav />
      </main>
    );
  }

  if (!profile) {
    return (
      <main className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-lg">User not found</p>
          <Link href="/" className="text-[#00d4ff] mt-2 inline-block">
            Go back home
          </Link>
        </div>
        <BottomNav />
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-black pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 glass border-b border-neutral-800">
        <div className="flex items-center gap-4 h-14 px-4">
          <Link
            href="/"
            className="p-2 hover:bg-neutral-800 rounded-lg transition-colors"
          >
            <ArrowLeft size={20} />
          </Link>
          <div>
            <h1 className="font-semibold text-white">{profile.name}</h1>
            <p className="text-xs text-neutral-500">
              {profile.followers.length} followers
            </p>
          </div>
        </div>
      </div>

      {/* Cover */}
      <div className="h-32 bg-gradient-to-r from-[#00d4ff]/20 to-purple-600/20" />

      {/* Profile Info */}
      <div className="px-4 -mt-16">
        <div className="flex justify-between items-end">
          <Avatar
            src={profile.avatar}
            name={profile.name}
            size="xl"
            className="border-4 border-black"
          />

          {!isOwnProfile && (
            <div className="flex gap-2 mb-2">
              <button
                onClick={handleConnect}
                disabled={isConnected || connectionPending}
                className={cn(
                  'flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors',
                  isConnected
                    ? 'bg-neutral-800 text-white'
                    : 'bg-[#00d4ff] text-black hover:bg-[#00d4ff]/90'
                )}
              >
                {isConnected ? (
                  <>
                    <UserCheck size={18} />
                    Connected
                  </>
                ) : (
                  <>
                    <UserPlus size={18} />
                    Connect
                  </>
                )}
              </button>
              <button className="p-2 bg-neutral-800 rounded-xl hover:bg-neutral-700 transition-colors">
                <MessageCircle size={20} />
              </button>
            </div>
          )}

          {isOwnProfile && (
            <Link
              href="/profile/edit"
              className="px-4 py-2 bg-neutral-800 text-white rounded-xl font-medium hover:bg-neutral-700 transition-colors mb-2"
            >
              Edit Profile
            </Link>
          )}
        </div>

        <div className="mt-4">
          <h2 className="text-xl font-bold text-white">{profile.name}</h2>
          <p className="text-neutral-500">@{profile.username}</p>
        </div>

        {profile.bio && (
          <p className="mt-3 text-white whitespace-pre-wrap">{profile.bio}</p>
        )}

        {/* Details */}
        <div className="flex flex-wrap gap-4 mt-4 text-sm text-neutral-400">
          {profile.location && (
            <div className="flex items-center gap-1">
              <MapPin size={16} />
              <span>{profile.location}</span>
            </div>
          )}
          {profile.website && (
            <a
              href={profile.website}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-[#00d4ff] hover:underline"
            >
              <LinkIcon size={16} />
              <span>{profile.website.replace(/^https?:\/\//, '')}</span>
            </a>
          )}
          {profile.companyName && (
            <div className="flex items-center gap-1">
              <Briefcase size={16} />
              <span>{profile.companyName}</span>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="flex gap-6 mt-4 py-4 border-y border-neutral-800">
          <div className="text-center">
            <span className="font-bold text-white">{profile.following.length}</span>
            <p className="text-sm text-neutral-500">Following</p>
          </div>
          <div className="text-center">
            <span className="font-bold text-white">{profile.followers.length}</span>
            <p className="text-sm text-neutral-500">Followers</p>
          </div>
          <div className="text-center">
            <span className="font-bold text-white">{profile.connections.length}</span>
            <p className="text-sm text-neutral-500">Connections</p>
          </div>
        </div>

        {/* Skills */}
        {profile.skills.length > 0 && (
          <div className="mt-4">
            <h3 className="text-sm font-medium text-neutral-400 mb-2">Skills</h3>
            <div className="flex flex-wrap gap-2">
              {profile.skills.map((skill, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-neutral-800 text-neutral-300 text-sm rounded-full"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Tech Stack */}
        {profile.techStack.length > 0 && (
          <div className="mt-4">
            <h3 className="text-sm font-medium text-neutral-400 mb-2">Tech Stack</h3>
            <div className="flex flex-wrap gap-2">
              {profile.techStack.map((tech, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-[#00d4ff]/10 text-[#00d4ff] text-sm rounded-full"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      <BottomNav />
    </main>
  );
}
