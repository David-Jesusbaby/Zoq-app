export interface User {
  id: string;
  email: string;
  username: string;
  name: string;
  avatar?: string;
  bio?: string;
  skills: string[];
  techStack: string[];
  role: 'geek' | 'company';
  companyName?: string;
  companySize?: string;
  website?: string;
  location?: string;
  followers: string[];
  following: string[];
  connections: string[];
  isVerified: boolean;
  badges: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  user: User;
  content: string;
  createdAt: string;
}

export interface Post {
  _id: string;
  author: User;
  content: string;
  images: string[];
  likes: string[];
  comments: Comment[];
  reposts: string[];
  originalPost?: Post;
  isRepost: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Connection {
  _id: string;
  requester: User;
  recipient: User;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  _id: string;
  recipient: string;
  sender: User;
  type: 'like' | 'comment' | 'connection_request' | 'connection_accepted' | 'repost' | 'mention';
  post?: Post;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface Story {
  _id: string;
  author: User;
  image: string;
  caption?: string;
  viewers: { user: User; viewedAt: string }[];
  expiresAt: string;
  createdAt: string;
}

export interface Message {
  _id: string;
  sender: User;
  recipient: User;
  content: string;
  isRead: boolean;
  readAt?: string;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}
