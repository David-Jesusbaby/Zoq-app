import mongoose, { Schema, Document } from 'mongoose';

export interface IStoryViewer {
  user: mongoose.Types.ObjectId;
  viewedAt: Date;
}

export interface IStory extends Document {
  author: mongoose.Types.ObjectId;
  image: string;
  caption?: string;
  viewers: IStoryViewer[];
  expiresAt: Date;
  createdAt: Date;
}

const StoryViewerSchema = new Schema<IStoryViewer>({
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  viewedAt: {
    type: Date,
    default: Date.now,
  },
});

const StorySchema = new Schema<IStory>(
  {
    author: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    image: {
      type: String,
      required: true,
    },
    caption: {
      type: String,
      maxlength: 200,
    },
    viewers: [StoryViewerSchema],
    expiresAt: {
      type: Date,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// Create indexes
StorySchema.index({ author: 1, createdAt: -1 });
StorySchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

export default mongoose.models.Story || mongoose.model<IStory>('Story', StorySchema);
