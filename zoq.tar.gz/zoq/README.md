# ZOQ - Tech Social Network

A global tech networking platform connecting developers, engineers, startups, and companies.

## Features

- **Authentication**: JWT-based auth with signup/login
- **Profile System**: Multi-step onboarding, skills, tech stack
- **Connection System**: Send/accept connection requests
- **Feed System**: Create posts, like, comment, repost
- **Story System**: 24-hour expiring stories
- **Notifications**: Real-time notifications
- **Search**: Find users, posts, and filter by skills
- **Real-time Chat**: Socket.io powered messaging

## Tech Stack

- **Frontend**: Next.js 14, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, Socket.io
- **Database**: MongoDB with Mongoose
- **Authentication**: JWT, bcrypt

## Getting Started

### Prerequisites

- Node.js 18+
- MongoDB (local or Atlas)

### Installation

1. Clone the repository:
```bash
git clone <repo-url>
cd zoq
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.local.example .env.local
# Edit .env.local with your values
```

4. Run the development server:
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Environment Variables

```env
MONGODB_URI=mongodb://localhost:27017/zoq
JWT_SECRET=your-super-secret-key
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## Deployment

### Deploy to Vercel

1. Push your code to GitHub
2. Connect your repo to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy!

### Deploy Database (MongoDB Atlas)

1. Create a free cluster at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Get your connection string
3. Add to environment variables

## Project Structure

```
zoq/
├── src/
│   ├── app/              # Next.js App Router
│   │   ├── api/          # API routes
│   │   ├── page.tsx      # Home page
│   │   ├── login/        # Login page
│   │   ├── register/     # Register page
│   │   ├── profile/      # Profile pages
│   │   ├── search/       # Search page
│   │   ├── notifications/# Notifications page
│   │   └── messages/     # Messages page
│   ├── components/       # React components
│   │   ├── ui/           # UI components
│   │   ├── layout/       # Layout components
│   │   ├── feed/         # Feed components
│   │   ├── stories/      # Story components
│   │   └── ...
│   ├── context/          # React contexts
│   ├── hooks/            # Custom hooks
│   ├── lib/              # Utilities
│   │   ├── db/           # Database connection
│   │   ├── auth/         # Auth utilities
│   │   └── socket/       # Socket.io setup
│   ├── models/           # Mongoose models
│   ├── types/            # TypeScript types
│   └── utils/            # Helper functions
├── public/               # Static files
└── package.json
```

## API Routes

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Users
- `GET /api/users/me` - Get current user
- `PUT /api/users/me` - Update current user
- `GET /api/users/[username]` - Get user by username

### Posts
- `GET /api/posts` - Get feed posts
- `POST /api/posts` - Create post
- `POST /api/posts/[id]/like` - Like/unlike post
- `POST /api/posts/[id]/comment` - Comment on post

### Connections
- `GET /api/connections` - Get connections
- `POST /api/connections` - Send connection request
- `PUT /api/connections/[id]` - Accept/reject request
- `DELETE /api/connections/[id]` - Remove connection

### Notifications
- `GET /api/notifications` - Get notifications
- `PUT /api/notifications` - Mark all as read

### Stories
- `GET /api/stories` - Get active stories
- `POST /api/stories` - Create story

### Search
- `GET /api/search?q=query&type=users` - Search users/posts

## License

MIT
